  function fun()
   {  document.write("Hi, I am from outside!")
     }
